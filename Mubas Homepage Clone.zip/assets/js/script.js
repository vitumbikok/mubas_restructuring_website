function myFunction(item) {
  document.getElementById(item).classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function (e) {
  if (!e.target.matches(".dropbtn")) {
    var myDropdown = document.getElementById("facilities");
    if (myDropdown.classList.contains("show")) {
      myDropdown.classList.remove("show");
      myDropdown.style.backgroundColor = "#1b5f9a";
    }
  }
};
